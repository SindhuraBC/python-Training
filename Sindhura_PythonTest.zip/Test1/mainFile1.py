def rf(tied, names):
    headers = ['tied', 'name']
    rows = list(zip(tied, names))
    SortedRows=[]
    for i in rows:
        if int(i[0])>=1:
            SortedRows.append(i) 
    return SortedRows           
    #print_table(headers, SortedRows, formatter)
    
