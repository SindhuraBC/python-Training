def rf(tied, names):
    headers = ['tied', 'name']
    rows = list(zip(tied, names))
    return(max(rows)[1])
  
