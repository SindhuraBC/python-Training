'''
    Print a table of columns
'''
class TableFormatter:
    def headers(self, titles):
        raise NotImplementedError()

    def row(self, rowdata):
        raise NotImplementedError()

class TextTableFormatter(TableFormatter):
    def headers(self, titles):
        for title in titles:
            print(f'{title:>10}', end=' ')
        print()

        dashes = "-" * 10 + ' '
        dashes = dashes * len(titles)
        print(dashes)

    def row(self, rowdata):
        for field in rowdata:
            print(f'{field:>10}', end=' ')
        print()
        
def create_table_formatter(fmt):
    if fmt == "txt":
        return TextTableFormatter()
    elif fmt == "csv":
        return CsvTableFormatter()
    else:
        raise RuntimeError(f'unknown format : {fmt}')

def print_table(headers, rows, formatter):
    formatter.headers(headers)
    for row in rows:
        formatter.row(row)

def print_stats(numbers):
    total = sum(numbers)
    n_caps = len(numbers)
    print("Average wins", round(total/n_caps, 2))
    print("Min wins", min(numbers))
    print("Max wins", max(numbers))

#cap_tied = read_col("../captains.txt", "tied", int)
#print_stats(cap_tied)
